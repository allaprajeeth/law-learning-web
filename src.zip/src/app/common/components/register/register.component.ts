import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
 // constructor(private router: Router) {}
 images: string[] = [
  'assets/law.img1.png',
  'assets/law.img2.png',
  'assets/law.img3.png',
  'assets/law.img4.png'
  // Add more image paths as needed
];

currentIndex: number = 0;
interval: any;
username: string = '';
password: string = '';

ngOnInit() {
  this.startAutoCarousel();
}

ngOnDestroy() {
  this.stopAutoCarousel();
}

startAutoCarousel() {
  this.interval = setInterval(() => {
    this.nextImage();
  }, 3000); // Change image every 3 seconds (adjust as needed)
}

stopAutoCarousel() {
  clearInterval(this.interval);
}

nextImage() {
  this.currentIndex = (this.currentIndex + 1) % this.images.length;
}

prevImage() {
  this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
}




  selectedCategory: any;
  
  constructor(private router: Router) {} // Inject the Router module

  onCategoryChange(event: any) {
    this.selectedCategory = event.target.value;
    this.router.navigate(['/register']);

}
}
