import { Component } from '@angular/core';

interface SubSection {
  title: string;
  file?: File;
}

interface MainSection {
  name: string;
  file?: File;
  subSections: SubSection[];
}

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent {
  mainSections: MainSection[] = [];

  addMainSection() {
    const newMainSection: MainSection = {
      name: `Section ${this.mainSections.length + 1}`,
      subSections: []
    };
    this.mainSections.push(newMainSection);
  }

  removeMainSection(index: number) {
    this.mainSections.splice(index, 1);
  }

  addSubSection(mainIndex: number) {
    const newSubSection: SubSection = {
      title: `Sub-Section ${this.mainSections[mainIndex].subSections.length + 1}`
    };
    this.mainSections[mainIndex].subSections.push(newSubSection);
  }

  removeSubSection(mainIndex: number, subIndex: number) {
    this.mainSections[mainIndex].subSections.splice(subIndex, 1);
  }

  
  onMainFileSelected(event: any, mainIndex: number) {
    const file = event.target.files[0];
    if (file) {
      this.mainSections[mainIndex].file = file;
    }
  }

  onSubFileSelected(event: any, mainIndex: number, subIndex: number) {
    const file = event.target.files[0];
    if (file) {
      this.mainSections[mainIndex].subSections[subIndex].file = file;
    }
  }

}

