import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
 
  isEmailFilled: boolean = true;
isPhoneFilled: boolean = true;
// isCategoryDisabled: boolean = true;





  images: string[] = [
    'assets/law.img1.png',
    'assets/law.img2.png',
    'assets/law.img3.png',
    'assets/law.img4.png'
    // Add more image paths as needed
  ];

  currentIndex: number = 0;
  interval: any;
  username: string = '';
  password: string = '';
  loginIsSuccessful: boolean = false;

  ngOnInit() {
    this.startAutoCarousel();
  }

  ngOnDestroy() {
    this.stopAutoCarousel();
  }

  startAutoCarousel() {
    this.interval = setInterval(() => {
      this.nextImage();
    }, 3000); // Change image every 3 seconds (adjust as needed)
  }

  stopAutoCarousel() {
    clearInterval(this.interval);
  }

  nextImage() {
    this.currentIndex = (this.currentIndex + 1) % this.images.length;
  }

  prevImage() {
    this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
  }

  showNextButton: boolean = true;
  phoneOtp: string = '';
  emailOtp: string = ''; // Initialize the emailOtp property
  showValidationError: boolean = false;

  // Define an EventEmitter to emit the closeSignup event
  @Output() closeSignup = new EventEmitter<void>();



  selectedCategory: string = ''; // Initialize with an empty string
  showLoginForm: boolean = true; 

  showSignupForm() {
    this.showLoginForm = false; // Set to false to show the signup form
  }
  onCloseSignup() {
    this.closeSignup.emit();
  }
  constructor(private router: Router) {} // Inject the Router module
  
  showNextForm() {
    this.showNextButton = false;
  }

  onCategoryChange(event: any): void {
    
      this.selectedCategory = event.target.value;
      this.validateFields();
    
  } 

  validateFields(): void {
    this.isEmailFilled = !!this.username; // Check if email is filled
    this.isPhoneFilled = !!this.password; // Check if phone number is filled

    // Disable category dropdown if email or phone number is not filled
    // this.isCategoryDisabled = !this.isEmailFilled || !this.isPhoneFilled;

    // console.log('isEmailFilled:', this.isEmailFilled);
    // console.log('isPhoneFilled:', this.isPhoneFilled);
    // console.log('isCategoryDisabled:', this.isCategoryDisabled);
}

  fnLogin(event: Event): void {
  
  // Define route based on selected category
    let route: string = ''; // Initialize route with an empty string or default route

    if (this.selectedCategory === 'Subscriber') {
      route = 'subscriber/homepage';
    } else if (this.selectedCategory === 'Instructor') {
      route = 'instructor/homepage';
    } else if (this.selectedCategory === 'Reviewer') {
      route = 'reviewer/homepage';
    }

    // Navigate to the corresponding homepage route
    this.router.navigate([route]);
  }




  
  }
  

















  


  