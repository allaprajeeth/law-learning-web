import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reviewer-login',
  templateUrl: './reviewer-login.component.html',
  styleUrls: ['./reviewer-login.component.scss']
})
export class ReviewerLoginComponent {

 
}
