import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared-module/shared.module';

import { ReviewerRoutingModule } from './reviewer-routing.module';
import { ReviewerLoginComponent } from './components/reviewer-login/reviewer-login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ReviewernavComponent } from './components/reviewernav/reviewernav.component';


import {MatMenuModule} from '@angular/material/menu';
import {MatSelectModule} from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
import {MatBadgeModule} from '@angular/material/badge';
import { HomepageComponent } from './components/homepage/homepage.component';

@NgModule({
  declarations: [
    ReviewerLoginComponent,
    ReviewernavComponent,
    HomepageComponent,
    // InstructorLoginComponent
  ],
  imports: [
    CommonModule,
    ReviewerRoutingModule,
    SharedModule,

    ReactiveFormsModule,
    MatIconModule,
    MatMenuModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTooltipModule,
    MatBadgeModule



  ]
})
export class ReviewerModule { }
