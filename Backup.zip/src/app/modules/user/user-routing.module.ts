import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { ProfileComponent } from './profile/profile.component';
import { PhotoComponent } from './photo/photo.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { MainnavComponent } from './mainnav/mainnav.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { MylearningComponent } from './mylearning/mylearning.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { MessagesComponent } from './messages/messages.component';
import { CartComponent } from './cart/cart.component';
import { CreditsComponent } from './credits/credits.component';

import { PaymentComponent } from './payment/payment.component';
import { PurchasehistoryComponent } from './purchasehistory/purchasehistory.component';
import { SubscriptionsComponent } from './subscriptions/subscriptions.component';
import { AccountsecurityComponent } from './accountsecurity/accountsecurity.component';
import { NavComponent } from 'src/app/common/components/nav/nav.component';
import { VideocontainerComponent } from './videocontainer/videocontainer.component';

const routes: Routes = [
  
  {
    path: "userprofile",
    component: UserprofileComponent
  },
  {
    path:'profile', 
    component: ProfileComponent
  },
  {
    path:'photo', 
    component: PhotoComponent
  },
  {
    path:'sidenav', 
    component: SidenavComponent
  },
  {
    path:'mainanv', 
    component: MainnavComponent
  },
  {
    path:'privacy', 
    component: PrivacyComponent
  },
  {
    path:'mylearning', 
    component: MylearningComponent
  },
  {
    path:'wishlist', 
    component: WishlistComponent
  },
  {
    path:'messages', 
    component: MessagesComponent
  },
  {
    path:'cart', 
    component: CartComponent
  },
  {
    path:'credits', 
    component: CreditsComponent
  },
  
  {
    path:'payment', 
    component: PaymentComponent
  },
  {
    path:'purchasehistory', 
    component: PurchasehistoryComponent
  },
  {
    path:'subscriptions', 
    component: SubscriptionsComponent
  },
  {
    path:'accountsecurity', 
    component: AccountsecurityComponent
  },

  // {
  //   path:'', 
  //   component: NavComponent
  // }
 
  
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
