import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { PhotoComponent } from './photo/photo.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { MainnavComponent } from './mainnav/mainnav.component';
import { ProfileComponent } from './profile/profile.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';

import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { MylearningComponent } from './mylearning/mylearning.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { MessagesComponent } from './messages/messages.component';
import { PaymentComponent } from './payment/payment.component';
import { CartComponent } from './cart/cart.component';
import { PurchasehistoryComponent } from './purchasehistory/purchasehistory.component';
import { CreditsComponent } from './credits/credits.component';
import { AccountsecurityComponent } from './accountsecurity/accountsecurity.component';

import { SubscriptionsComponent } from './subscriptions/subscriptions.component';
import {MatTabsModule} from '@angular/material/tabs';
import { UserLoginComponent } from './components/user-login/user-login.component';
import { VideocontainerComponent } from './videocontainer/videocontainer.component';


@NgModule({
  declarations: [
    UserprofileComponent,
    PhotoComponent,
    PrivacyComponent,
    SidenavComponent,
    MainnavComponent,
    ProfileComponent,
    MylearningComponent,
    WishlistComponent,
    MessagesComponent,
    PaymentComponent,
    CartComponent,
    PurchasehistoryComponent,
    CreditsComponent,
    AccountsecurityComponent,
    
    SubscriptionsComponent,
         UserLoginComponent,
         VideocontainerComponent,
    
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    MatSidenavModule,
    MatFormFieldModule,
    MatSelectModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatTabsModule
  ]
})
export class UserModule { }
