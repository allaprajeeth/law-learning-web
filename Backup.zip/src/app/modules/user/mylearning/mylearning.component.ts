import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mylearning',
  templateUrl: './mylearning.component.html',
  styleUrls: ['./mylearning.component.scss']
})
export class MylearningComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    document.addEventListener('DOMContentLoaded', () => {
      const allCoursesLink = document.getElementById('allCoursesLink');
      const allCoursesLinkBottom = document.getElementById('allCoursesLinkBottom');
      const allCoursesLinkArchived = document.getElementById('allCoursesLinkArchived');
      const contentArea = document.getElementById('contentArea');
      const listInfo = document.getElementById('listInfo');
      const wishlistInfo = document.getElementById('wishlistInfo');
      const archivedInfo = document.getElementById('archivedInfo');

      if (allCoursesLink) {
        allCoursesLink.addEventListener('click', (event) => {
          event.preventDefault();
          if (contentArea) {
            contentArea.textContent = 'All courses';
          }
          if (listInfo) {
            listInfo.style.display = 'none';
          }
          if (wishlistInfo) {
            wishlistInfo.style.display = 'none';
          }
          if (archivedInfo) {
            archivedInfo.style.display = 'none';
          }
        });
      }

      // Similar checks for other event listeners...

      const myListsLink = document.getElementById('myListsLink');
      const wishlistLink = document.getElementById('wishlistLink');
      const archivedLink = document.getElementById('archivedLink');
      const browseCoursesButton = document.getElementById('browseCoursesButton');

      if (myListsLink) {
        myListsLink.addEventListener('click', (event) => {
          event.preventDefault();
          if (contentArea) {
            contentArea.textContent = '';
          }
          if (listInfo) {
            listInfo.style.display = 'block';
          }
          if (wishlistInfo) {
            wishlistInfo.style.display = 'none';
          }
          if (archivedInfo) {
            archivedInfo.style.display = 'none';
          }
        });
      }

      // Similar checks for other event listeners...

      if (browseCoursesButton) {
        browseCoursesButton.addEventListener('click', (event) => {
          // Handle browseCoursesButton click event here
        });
      }
    });
  }
}
