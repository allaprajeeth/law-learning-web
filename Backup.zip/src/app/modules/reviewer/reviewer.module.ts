import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReviewerRoutingModule } from './reviewer-routing.module';
import { ReviewerLoginComponent } from './components/reviewer-login/reviewer-login.component';
// import { InstructorLoginComponent } from '../instructor/components/instructor-login/instructor-login.component';
import { SharedModule } from 'src/app/shared-module/shared.module';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    ReviewerLoginComponent,
    // InstructorLoginComponent
  ],
  imports: [
    CommonModule,
    ReviewerRoutingModule,
    SharedModule,
    ReactiveFormsModule
  ]
})
export class ReviewerModule { }
