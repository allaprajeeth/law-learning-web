import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SubscriberLoginComponent } from './components/subscriber-login/subscriber-login.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { NavComponent } from 'src/app/common/components/nav/nav.component';

const routes: Routes = [
  {
    path:"",
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path:"login",
    component: SubscriberLoginComponent
  },
  {
    path:'', 
    component: NavComponent
  }

  // {
  //   path:"sidenav",
  //   component: SidenavComponent
  // },
  // {
  //   path:'', 
  //   component: SidenavComponent
  // }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SubscriberRoutingModule { }
