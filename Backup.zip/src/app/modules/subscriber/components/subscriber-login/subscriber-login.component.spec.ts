import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscriberLoginComponent } from './subscriber-login.component';

describe('SubscriberLoginComponent', () => {
  let component: SubscriberLoginComponent;
  let fixture: ComponentFixture<SubscriberLoginComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SubscriberLoginComponent]
    });
    fixture = TestBed.createComponent(SubscriberLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
