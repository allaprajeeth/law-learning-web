import { Component } from '@angular/core';


@Component({
  selector: 'app-subscriber-login',
  templateUrl: './subscriber-login.component.html',
  styleUrls: ['./subscriber-login.component.scss']
})
export class SubscriberLoginComponent {

}
