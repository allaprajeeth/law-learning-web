import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SubscriberRoutingModule } from './subscriber-routing.module';
import { SubscriberLoginComponent } from './components/subscriber-login/subscriber-login.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { MainnavComponent } from './components/mainnav/mainnav.component';
import { CartComponent } from './components/cart/cart.component';
import { AccountsecurityComponent } from './components/accountsecurity/accountsecurity.component';
import { SubscriptionsComponent } from './components/subscriptions/subscriptions.component';



@NgModule({
  declarations: [
    SubscriberLoginComponent,
    SidenavComponent,
    MainnavComponent,
    CartComponent,
    AccountsecurityComponent,
    SubscriptionsComponent
  ],
  imports: [
    CommonModule,
    SubscriberRoutingModule
  ]
})
export class SubscriberModule { }
