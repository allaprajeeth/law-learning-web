import { Component } from '@angular/core';

@Component({
  selector: 'app-firstnav',
  templateUrl: './firstnav.component.html',
  styleUrls: ['./firstnav.component.scss']
})
export class FirstnavComponent {

}
