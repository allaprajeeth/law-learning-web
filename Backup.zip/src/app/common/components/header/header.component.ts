import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  // constructor(private router: Router) {}
  images: string[] = [
    'assets/law.img1.png',
    'assets/law.img2.png',
    'assets/law.img3.png',
    'assets/law.img4.png'
    // Add more image paths as needed
  ];

  currentIndex: number = 0;
  interval: any;
  username: string = '';
  password: string = '';

  ngOnInit() {
    this.startAutoCarousel();
  }

  ngOnDestroy() {
    this.stopAutoCarousel();
  }

  startAutoCarousel() {
    this.interval = setInterval(() => {
      this.nextImage();
    }, 3000); // Change image every 3 seconds (adjust as needed)
  }

  stopAutoCarousel() {
    clearInterval(this.interval);
  }

  nextImage() {
    this.currentIndex = (this.currentIndex + 1) % this.images.length;
  }

  prevImage() {
    this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
  }

  // Define an EventEmitter to emit the closeSignup event
  @Output() closeSignup = new EventEmitter<void>();


  selectedCategory: string = ''; // Initialize with an empty string
  showLoginForm: boolean = true;

  showSignupForm() {
    this.showLoginForm = false;
   
  }
// Example method to close the signup form
onCloseSignup() {
  // Emit the closeSignup event to notify the parent component
  this.closeSignup.emit();
}
  constructor(private router: Router) {} // Inject the Router module

  onCategoryChange(event: any) {
    this.selectedCategory = event.target.value;

    // Navigate to different routes based on the selected category
    switch (this.selectedCategory) {
      case 'Subscriber':
        this.router.navigate(['/subscriber']);
        break;
      case 'Reviewer':
        this.router.navigate(['/reviewer']);
        break;
      case 'Instructor':
        this.router.navigate(['/instructor']);
        break;
      default:
        // Handle other cases or provide a default route
        break;
    }
  }
}



